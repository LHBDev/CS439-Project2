#include <bitmap.h>

//Swap table methods
void swap_init (void);
void * swap_in (void *, int);
void swap_out (void *);
